use ciudadesColombia;
create table ciudades(
	CiudadID int primary key auto_increment,
    CiudadNombre varchar(25)
);

insert into ciudades(CiudadID,CiudadNombre) values (null,"Bogota");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Medellin");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Barranquilla");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Valledupar");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Bucaramanga");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Monteria");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Pereira");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Buenaventura");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Cali");
insert into ciudades(CiudadID,CiudadNombre) values (null,"Sincelejo");